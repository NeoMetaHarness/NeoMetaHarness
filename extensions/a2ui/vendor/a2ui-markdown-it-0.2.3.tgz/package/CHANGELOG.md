## Unreleased

- Bump `dompurify` to `^3.4.17` to resolve security advisories GHSA-cg2g-xh64-v4q7 and GHSA-mrv2-3pqr-j5jr ([#4278](https://github.com/a2ui-project/a2ui/issues/4278), [#4284](https://github.com/a2ui-project/a2ui/pull/4284)).

## 0.2.3

- Bump dependencies for compatibility with `@a2ui/web_core: ^0.16.0`.

## 0.2.2

- Bump dependencies for compatibility with `@a2ui/web_core: ^0.14.0`.
- Relocate package directory from `renderers/markdown/markdown-it` to `typescript/renderers/markdown-it`.

## 0.2.1

- Bump dependencies for compatibility with `@a2ui/web_core: ^0.13.0`.
- Enforce `noImplicitOverride: true` and forbid self-package imports ([#2878](https://github.com/a2ui-project/a2ui/pull/2878)).

## 0.2.0

- Re-export `MarkdownRenderer`, `MarkdownRendererOptions`, and `MarkdownRendererTagClassMap` directly from `@a2ui/web_core`.
- Bump dependencies for compatibility with `@a2ui/web_core: ^0.12.0`.

## 0.1.2

- Bump dependencies so the package is compatible with `@a2ui/web_core: ^0.11.0`.

## 0.1.1

- Enable `inlineSources` in `tsconfig.json` to populate `sourcesContent` in sourcemaps.

## 0.1.0

- Bump dependencies so the package is compatible with `@a2ui/web_core: ^0.10.3`.

## 0.0.2

- Made the markdown renderer async to support async markdown renderers.

## 0.0.1

- Initial release

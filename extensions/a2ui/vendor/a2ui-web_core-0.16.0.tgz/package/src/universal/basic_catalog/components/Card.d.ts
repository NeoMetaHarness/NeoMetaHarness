import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { CardSupportedApis } from './supported_apis.js';
export declare class A2uiCardElement extends BasicCatalogA2uiLitElement<CardSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-card";
    /**
     * The styles of the card can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-card-padding`: Padding of the card. Defaults to `--a2ui-spacing-m`.
     * - `--a2ui-card-border-radius`: Border radius of the card. Defaults to `--a2ui-border-radius`.
     * - `--a2ui-card-box-shadow`: Box shadow of the card. Defaults to `0 2px 4px rgba(0, 0, 0, 0.1)`.
     * - `--a2ui-card-background`: Background of the card. Defaults to `--a2ui-color-surface`.
     * - `--a2ui-card-border`: Border shorthand of the card. Defaults to `var(--a2ui-border-width) solid var(--a2ui-color-border)`.
     * - `--a2ui-card-margin`: Outer margin of the card. Defaults to `--a2ui-spacing-m`.
     *
     * Global theme variables read by this component:
     *
     * - `--a2ui-color-surface`: Fallback background color of the card.
     * - `--a2ui-color-on-surface`: Text color inside the card.
     * - `--a2ui-border-radius`: Fallback border radius of the card.
     * - `--a2ui-border-width`: Fallback border width of the card.
     * - `--a2ui-color-border`: Fallback border color of the card.
     * - `--a2ui-spacing-m`: Fallback padding and outer margin of the card.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=Card.d.ts.map
import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { AudioPlayerSupportedApis } from './supported_apis.js';
export declare class A2uiAudioPlayerElement extends BasicCatalogA2uiLitElement<AudioPlayerSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-audioplayer";
    /**
     * The styles of the audio player can be customized by redefining the
     * following CSS variables:
     *
     * - `--a2ui-audioplayer-background`: Background of the player container. Defaults to `transparent`.
     * - `--a2ui-audioplayer-border-radius`: Border radius of the player container. Defaults to `0`.
     * - `--a2ui-audioplayer-padding`: Padding of the player container. Defaults to `0`.
     * - `--a2ui-audioplayer-description-color`: Text color of the description. Defaults to `--a2ui-text-caption-color`, then `light-dark(#666, #aaa)`.
     *
     * Global theme variables read by this component:
     *
     * - `--a2ui-spacing-xs`: Gap between the description and audio controls.
     * - `--a2ui-font-size-s`: Font size of the description.
     * - `--a2ui-text-caption-color`: Fallback text color for the description. Defaults to `light-dark(#666, #aaa)`.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=AudioPlayer.d.ts.map
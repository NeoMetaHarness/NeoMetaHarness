import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { ModalSupportedApis } from './supported_apis.js';
export declare class A2uiLitModal extends BasicCatalogA2uiLitElement<ModalSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-modal";
    /**
     * The styles of the modal can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-modal-backdrop-bg`: Background of the modal overlay backdrop. Defaults to `rgba(0, 0, 0, 0.5)`.
     * - `--a2ui-modal-background`: Background of the modal dialog surface. Defaults to `--a2ui-color-surface`.
     * - `--a2ui-modal-padding`: Padding of the modal dialog surface. Defaults to `--a2ui-spacing-xl`.
     * - `--a2ui-modal-border-radius`: Border radius of the modal dialog surface. Defaults to `--a2ui-border-radius`.
     * - `--a2ui-modal-box-shadow`: Box shadow of the modal dialog surface. Defaults to `0 10px 25px rgba(0, 0, 0, 0.2)`.
     *
     * Global theme variables read by this component:
     *
     * - `--a2ui-color-surface`: Fallback background color of the modal dialog surface.
     * - `--a2ui-spacing-xl`: Fallback padding of the modal dialog surface.
     * - `--a2ui-border-radius`: Fallback border radius of the modal dialog surface.
     * - `--a2ui-text-caption-color`: Text color of the close button. Defaults to `#999`.
     * - `--a2ui-text-color`: Hover text color of the close button. Defaults to `#333`.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    isOpen: boolean;
    openModal(): void;
    closeModal(): void;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
export { A2uiLitModal as A2uiModalElement };
//# sourceMappingURL=Modal.d.ts.map
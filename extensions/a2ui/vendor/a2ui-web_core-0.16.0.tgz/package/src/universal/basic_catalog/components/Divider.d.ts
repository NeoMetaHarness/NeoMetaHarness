import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { DividerSupportedApis } from './supported_apis.js';
export declare class A2uiDividerElement extends BasicCatalogA2uiLitElement<DividerSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-divider";
    /**
     * The styles of the divider can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-divider-border`: Border shorthand for the divider line. Defaults to `var(--a2ui-border-width) solid var(--a2ui-color-border)`.
     * - `--a2ui-divider-spacing`: Block or inline margin around the divider. Defaults to `--a2ui-spacing-m`.
     *
     * Global theme variables read by this component:
     *
     * - `--a2ui-border-width`: Width of vertical dividers and fallback border width.
     * - `--a2ui-color-border`: Fallback border color of the divider.
     * - `--a2ui-spacing-m`: Fallback spacing around the divider.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=Divider.d.ts.map
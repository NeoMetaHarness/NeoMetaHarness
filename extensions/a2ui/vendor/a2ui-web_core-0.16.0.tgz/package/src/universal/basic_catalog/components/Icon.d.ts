import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { IconSupportedApis } from './supported_apis.js';
export declare class A2uiIconElement extends BasicCatalogA2uiLitElement<IconSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-icon";
    /**
     * The icon component can be customized with the following CSS variables:
     *
     * - `--a2ui-icon-size`: Width, height, and font size of the icon. Defaults to `24px`.
     * - `--a2ui-icon-color`: Color tint applied to the icon. Defaults to `--a2ui-text-color-text`, then `--a2ui-color-on-background`.
     * - `--a2ui-icon-font-family`: Font family for ligature icons. Defaults to `'Material Icons', 'Material Symbols Outlined'`.
     * - `--a2ui-icon-font-variation-settings`: Font variation settings for variable icon fonts. Defaults to `'FILL' 1`.
     *
     * Global theme variables read by this component:
     *
     * - `--a2ui-text-color-text`: Fallback color of the icon. Defaults to `--a2ui-color-on-background`.
     * - `--a2ui-color-on-background`: Fallback color of the icon when `--a2ui-text-color-text` is unset.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=Icon.d.ts.map
import { nothing, PropertyValues } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { ColumnSupportedApis } from './supported_apis.js';
export declare class A2uiBasicColumnElement extends BasicCatalogA2uiLitElement<ColumnSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-basic-column";
    /**
     * The styles of the column can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-column-gap`: Gap between items in the column. Defaults to `--a2ui-spacing-m`.
     * - `--a2ui-column-width`: Width of the column. Defaults to `100%`.
     *
     * Global theme variables read by this component:
     *
     * - `--a2ui-spacing-m`: Fallback gap between items in the column.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    updated(changedProperties: PropertyValues): void;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=Column.d.ts.map
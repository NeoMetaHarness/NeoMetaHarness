import { nothing } from 'lit';
import { BasicCatalogA2uiLitElement } from './basic-catalog-a2ui-lit-element.js';
import type { ButtonSupportedApis } from './supported_apis.js';
/**
 * A button component that can be used to trigger an action.
 */
export declare class A2uiBasicButtonElement extends BasicCatalogA2uiLitElement<ButtonSupportedApis> {
    /** @nocollapse */
    static readonly tagName = "a2ui-basic-button";
    /**
     * The styles of the button can be customized by redefining the following
     * CSS variables:
     *
     * - `--a2ui-button-padding`: Padding of the default and `primary` variants (`borderless` forces `0`). Defaults to `--a2ui-spacing-m` vertically and `--a2ui-spacing-l` horizontally.
     * - `--a2ui-button-border-radius`: Border radius of the button. Defaults to `--a2ui-spacing-s`.
     * - `--a2ui-button-border`: Border shorthand of the default variant. Defaults to `var(--a2ui-border-width) solid var(--a2ui-color-border)`.
     * - `--a2ui-button-margin`: Outer margin of the button. Defaults to `--a2ui-spacing-m`.
     * - `--a2ui-button-background`: Background of the default variant. Defaults to `--a2ui-color-surface`.
     * - `--a2ui-button-box-shadow`: Box shadow of the button. Defaults to `none`.
     * - `--a2ui-button-font-weight`: Font weight of the button text. Defaults to `normal`.
     *
     * Global theme variables read by this component:
     *
     * - `--a2ui-color-primary`: Background of the `primary` variant and text color of the `borderless` variant.
     * - `--a2ui-color-primary-hover`: Hover background color of the `primary` variant.
     * - `--a2ui-color-on-primary`: Text color on the `primary` variant.
     * - `--a2ui-color-surface`: Fallback background color of the default variant.
     * - `--a2ui-color-secondary-hover`: Hover background color of the default variant.
     * - `--a2ui-color-on-secondary`: Text color on the default variant.
     * - `--a2ui-border-width`: Fallback border width of the default variant.
     * - `--a2ui-color-border`: Fallback border color of the default variant.
     * - `--a2ui-spacing-s`: Fallback border radius of the button.
     * - `--a2ui-spacing-m`: Fallback vertical padding and outer margin of the button.
     * - `--a2ui-spacing-l`: Fallback horizontal padding of the button.
     *
     * @nocollapse
     */
    static styles: import("lit").CSSResult;
    render(): typeof nothing | import("lit-html").TemplateResult<1>;
}
//# sourceMappingURL=Button.d.ts.map